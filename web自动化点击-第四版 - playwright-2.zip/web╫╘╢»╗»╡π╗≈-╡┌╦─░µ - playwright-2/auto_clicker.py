from playwright.sync_api import sync_playwright, TimeoutError
import time
import logging
import json
from datetime import datetime
import os

class AutoClicker:
    def __init__(self):
        self.setup_logging()
        self.visited_urls = set()
        self.clicked_elements = set()
        self.setup_results_dir()

    def setup_logging(self):
        """设置日志"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('auto_clicker.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)

    def setup_results_dir(self):
        """创建结果目录"""
        self.results_dir = f"results_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.screenshots_dir = os.path.join(self.results_dir, "screenshots")
        os.makedirs(self.screenshots_dir, exist_ok=True)

    async def start(self, url):
        """启动自动点击程序"""
        with sync_playwright() as p:
            # 启动浏览器
            browser = p.chromium.launch(headless=False)
            context = browser.new_context()
            page = context.new_page()

            try:
                self.logger.info(f"开始访问页面: {url}")
                await self.process_page(page, url)
            except Exception as e:
                self.logger.error(f"处理页面时出错: {str(e)}")
            finally:
                context.close()
                browser.close()

    async def process_page(self, page, url, depth=0):
        """处理页面"""
        if url in self.visited_urls or depth > 3:  # 限制深度
            return

        try:
            # 访问页面
            await page.goto(url, wait_until="networkidle")
            self.visited_urls.add(url)

            # 等待页面加载
            await page.wait_for_load_state("domcontentloaded")
            
            # 自动滚动页面加载所有内容
            await self.auto_scroll(page)

            # 获取可点击元素
            clickable_elements = await self.get_clickable_elements(page)
            self.logger.info(f"找到 {len(clickable_elements)} 个可点击元素")

            # 处理每个元素
            for element in clickable_elements:
                try:
                    await self.handle_element(page, element, url, depth)
                except Exception as e:
                    self.logger.error(f"处理元素时出错: {str(e)}")

        except Exception as e:
            self.logger.error(f"处理页面 {url} 时出错: {str(e)}")
            await self.take_screenshot(page, "error")

    async def get_clickable_elements(self, page):
        """获取可点击元素"""
        return await page.query_selector_all("""
            button, 
            a[href]:not([href^='javascript:']), 
            input[type='button'], 
            input[type='submit'],
            [role='button'],
            [onclick],
            .btn,
            [class*='button']
        """)

    async def handle_element(self, page, element, current_url, depth):
        """处理单个元素"""
        try:
            # 获取元素信息
            element_info = await self.get_element_info(element)
            element_id = element_info['selector']

            if element_id in self.clicked_elements:
                return

            # 记录操作前的状态
            original_url = page.url
            original_handles = page.context.pages

            # 高亮显示元素
            await self.highlight_element(element)

            # 截图
            await self.take_screenshot(page, f"before_click_{element_info['tag']}")

            # 尝试点击元素
            try:
                await element.click(timeout=5000)
                self.clicked_elements.add(element_id)
                self.logger.info(f"成功点击元素: {element_info['text']}")

                # 等待可能的导航或AJAX请求
                await page.wait_for_load_state("networkidle")

                # 处理新窗口
                new_handles = [p for p in page.context.pages if p not in original_handles]
                if new_handles:
                    for new_page in new_handles:
                        new_url = new_page.url
                        if new_url not in self.visited_urls:
                            await self.process_page(new_page, new_url, depth + 1)
                        await new_page.close()

                # 如果URL改变，处理新页面
                if page.url != original_url:
                    if page.url not in self.visited_urls:
                        await self.process_page(page, page.url, depth + 1)
                    await page.goto(original_url)
                    await page.wait_for_load_state("networkidle")

            except Exception as e:
                self.logger.error(f"点击元素失败: {str(e)}")
                await self.take_screenshot(page, "click_error")

        except Exception as e:
            self.logger.error(f"处理元素时出错: {str(e)}")

    async def get_element_info(self, element):
        """获取元素信息"""
        tag = await element.evaluate("el => el.tagName.toLowerCase()")
        text = await element.text_content() or await element.get_attribute("value") or ""
        selector = await element.evaluate("""el => {
            if (el.id) return `#${el.id}`;
            if (el.className) return `.${el.className.split(' ').join('.')}`;
            return el.tagName.toLowerCase();
        }""")
        
        return {
            'tag': tag,
            'text': text.strip(),
            'selector': selector
        }

    async def highlight_element(self, element):
        """高亮显示元素"""
        await element.evaluate("""el => {
            el.style.border = '2px solid red';
            el.style.backgroundColor = 'yellow';
            setTimeout(() => {
                el.style.border = '';
                el.style.backgroundColor = '';
            }, 1000);
        }""")
        await asyncio.sleep(1)

    async def auto_scroll(self, page):
        """自动滚动页面"""
        await page.evaluate("""
            async () => {
                await new Promise((resolve) => {
                    let totalHeight = 0;
                    const distance = 100;
                    const timer = setInterval(() => {
                        const scrollHeight = document.body.scrollHeight;
                        window.scrollBy(0, distance);
                        totalHeight += distance;
                        
                        if(totalHeight >= scrollHeight){
                            clearInterval(timer);
                            resolve();
                        }
                    }, 100);
                });
            }
        """)

    async def take_screenshot(self, page, name):
        """截图"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{name}_{timestamp}.png"
        await page.screenshot(path=os.path.join(self.screenshots_dir, filename))

def main():
    url = input("请输入要测试的网址: ").strip()
    if not url:
        print("错误: URL不能为空")
        return

    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url

    try:
        clicker = AutoClicker()
        asyncio.run(clicker.start(url))
    except KeyboardInterrupt:
        print("\n程序被用户中断")
    except Exception as e:
        print(f"程序运行出错: {str(e)}")
    finally:
        print("\n程序已结束")
        input("按回车键退出...")

if __name__ == "__main__":
    import asyncio
    main() 