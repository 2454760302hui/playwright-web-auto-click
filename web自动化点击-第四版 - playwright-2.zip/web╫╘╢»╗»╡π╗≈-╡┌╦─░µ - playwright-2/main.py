from web_clicker import WebClicker
import os
import sys

def validate_url(url):
    """验证并格式化URL"""
    url = url.strip()
    
    # 如果URL为空返回None
    if not url:
        return None
        
    # 检查是否包含协议
    if not url.startswith(('http://', 'https://')):
        # 首先尝试https
        try:
            import requests
            https_url = 'https://' + url
            response = requests.head(https_url, timeout=5, allow_redirects=True)
            if response.status_code < 400:
                return https_url
        except:
            pass
            
        # 如果https失败，使用http
        return 'http://' + url
        
    return url

def main():
    try:
        url = input("请输入要测试的网址: ")
        url = validate_url(url)
        
        if not url:
            print("错误: URL不能为空")
            return
            
        # 询问是否限制遍历范围
        limit_urls = input("是否限制遍历范围？(y/n): ").lower() == 'y'
        allowed_urls = None
        
        if limit_urls:
            urls_input = input("请输入允许遍历的URL（多个URL用逗号分隔）: ")
            if urls_input.strip():
                allowed_urls = [validate_url(u.strip()) for u in urls_input.split(',')]
                allowed_urls = [u for u in allowed_urls if u]  # 移除无效URL
            
        print("\n正在初始化浏览器...")
        clicker = WebClicker('config/click_rules.yml')
        print("浏览器初始化成功")
        
        clicker.start(url, allowed_urls=allowed_urls)
        
    except KeyboardInterrupt:
        print("\n程序被用户中断")
    except Exception as e:
        print(f"程序运行出错: {str(e)}")
        import traceback
        traceback.print_exc()
    finally:
        print("\n程序已结束")
        input("按回车键退出...")

if __name__ == "__main__":
    main() 