from playwright.sync_api import sync_playwright, Browser, Page, TimeoutError
import yaml
import time
import os
from datetime import datetime
import logging
import traceback
from openpyxl import Workbook
from openpyxl.drawing.image import Image
from PIL import Image as PILImage

# 确保配置目录存在
os.makedirs('config', exist_ok=True)
os.makedirs('screenshots', exist_ok=True)

class WebClicker:
    def __init__(self, config_path):
        try:
            # 初始化基本属性
            self.running = True
            self.visited_urls = set()
            self.clicked_elements = set()
            self.visited_elements = set()
            self.current_url = None
            
            # 设置默认配置
            self.config = {
                'timeout': {
                    'page_load': 30000,  # playwright使用毫秒
                    'element_wait': 10000,
                    'dynamic_wait': 3000
                },
                'screenshot': {
                    'enabled': True,
                    'path': 'screenshots'
                },
                'click_behavior': {
                    'wait_time': 2,
                    'highlight': True,
                    'retry_count': 3
                }
            }
            
            # 初始化playwright
            self.setup_browser()
            
            # 设置日志
            self.setup_logging()
            
            # 创建必要的目录
            os.makedirs('screenshots', exist_ok=True)
            os.makedirs('logs', exist_ok=True)
            
            # 初始化Excel工作簿
            self.workbook = Workbook()
            self.sheet = self.workbook.active
            self.setup_excel()
            
            # 创建结果目录
            self.result_dir = f"result_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            self.screenshots_dir = os.path.join(self.result_dir, "screenshots")
            os.makedirs(self.screenshots_dir, exist_ok=True)
            
        except Exception as e:
            print(f"初始化失败: {str(e)}")
            raise

    def setup_browser(self):
        """设置浏览器"""
        try:
            print("正在启动浏览器...")
            self.playwright = sync_playwright().start()
            
            # 配置浏览器选项
            browser_args = [
                '--disable-gpu',
                '--disable-dev-shm-usage',
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-web-security',
                '--disable-notifications',
                '--disable-logging',
                '--log-level=3'
            ]
            
            # 启动浏览器 - 使用系统Chrome
            self.browser = self.playwright.chromium.launch(
                headless=False,
                channel='chrome',  # 使用系统Chrome
                args=browser_args,
                timeout=30000,
                executable_path=None,  # 自动查找系统Chrome
                slow_mo=100  # 添加延迟以提高稳定性
            )
            
            # 创建上下文
            self.context = self.browser.new_context(
                viewport={'width': 1366, 'height': 768},
                ignore_https_errors=True,
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'  # 使用最新的Chrome UA
            )
            
            # 配置上下文
            self.context.set_default_timeout(self.config['timeout']['page_load'])
            self.context.set_default_navigation_timeout(self.config['timeout']['page_load'])
            
            # 创建页面
            self.page = self.context.new_page()
            
            # 配置页面
            self.page.set_default_timeout(self.config['timeout']['page_load'])
            self.page.set_default_navigation_timeout(self.config['timeout']['page_load'])
            
            # 设置页面事件监听
            self.page.on('dialog', lambda dialog: dialog.dismiss())  # 自动关闭对话框
            self.page.on('pageerror', lambda err: print(f'页面错误: {err}'))  # 打印页面错误
            
            print("浏览器启动成功")
            
        except Exception as e:
            print(f"启动浏览器失败: {str(e)}")
            if hasattr(self, 'browser'):
                self.browser.close()
            if hasattr(self, 'playwright'):
                self.playwright.stop()
            raise

    def process_page(self, url, depth=0, parent_url=None, allowed_urls=None):
        """处理页面，包括自动遍历"""
        try:
            # 检查URL是否在允许列表中
            if allowed_urls and url not in allowed_urls:
                print(f"\n跳过非允许页面: {url}")
                return
            
            if depth > 5 or url in self.visited_urls:
                return
            
            print(f"\n{'='*50}")
            print(f"开始处理页面: {url}")
            print(f"当前深度: {depth}")
            print(f"{'='*50}\n")
            
            # 访问页面
            self.page.goto(url, wait_until='networkidle')
            self.visited_urls.add(url)
            self.current_url = url
            
            # 等待页面加载
            self.page.wait_for_load_state('domcontentloaded')
            time.sleep(2)
            
            # 获取所有可点击元素
            clickable_elements = self.get_clickable_elements()
            print(f"\n在页面中找到 {len(clickable_elements)} 个可点击元素")
            
            # 存储发现的新页面URL
            discovered_urls = set()
            
            # 处理当前页面的所有元素
            for idx, element in enumerate(clickable_elements, 1):
                try:
                    # 确保元素仍然有效
                    if not self.is_element_valid(element):
                        continue
                        
                    # 获取并打印元素信息
                    element_info = self.get_element_info(element)
                    print(f"\n{'-'*30}")
                    print(f"元素 {idx}/{len(clickable_elements)}:")
                    print(f"类型: {element_info['type']}")
                    print(f"文本: {element_info['text'][:100]}")
                    print(f"位置: {element_info['position']}")
                    
                    # 准备记录数据
                    row_data = {
                        'index': idx,
                        'type': element_info['type'],
                        'text': element_info['text'],
                        'position': element_info['position'],
                        'status': '',
                        'error': '',
                        'screenshot': ''
                    }
                    
                    # 尝试滚动到元素位置（修改后的滚动逻辑）
                    try:
                        print("\n正在滚动到元素位置...")
                        # 先尝试使用 Playwright 的内置滚动
                        element.scroll_into_view_if_needed()
                        time.sleep(0.5)
                        
                        # 如果元素仍然不在视口中，使用备用滚动方法
                        if not self.is_element_in_viewport(element):
                            # 获取元素位置
                            box = element.bounding_box()
                            if box:
                                # 使用 JavaScript 平滑滚动（修复后的版本）
                                self.page.evaluate("""(scrollY) => {
                                    window.scrollTo({
                                        top: scrollY,
                                        behavior: 'smooth'
                                    });
                                }""", max(0, box['y'] - 100))  # 向上偏移100像素，确保元素完全可见
                                time.sleep(0.5)
                
                    except Exception as scroll_error:
                        print(f"滚动失败: {str(scroll_error)}")
                        # 如果滚动失败，尝试直接点击（Playwright会自动滚动）
                        print("尝试直接点击...")
                    
                    # 高亮并截图
                    self.highlight_element(element)
                    screenshot_path = self.take_screenshot(f"before_click_{depth}_{idx}")
                    row_data['screenshot'] = screenshot_path
                    
                    # 尝试点击元素
                    try:
                        print("\n尝试点击元素...")
                        click_success = False
                        
                        # 方法1：直接点击
                        try:
                            element.click(timeout=5000, force=True)
                            click_success = True
                            print("直接点击成功")
                        except Exception as e:
                            print(f"直接点击失败: {str(e)}")
                            
                        # 方法2：使用JavaScript点击
                        if not click_success:
                            try:
                                self.page.evaluate("""(element) => {
                                    element.click();
                                    return true;
                                }""", element)
                                click_success = True
                                print("JavaScript点击成功")
                            except Exception as e:
                                print(f"JavaScript点击失败: {str(e)}")
                                
                        # 方法3：模拟鼠标点击
                        if not click_success:
                            try:
                                box = element.bounding_box()
                                if box:
                                    self.page.mouse.move(
                                        box['x'] + box['width'] / 2,
                                        box['y'] + box['height'] / 2
                                    )
                                    self.page.mouse.click(
                                        box['x'] + box['width'] / 2,
                                        box['y'] + box['height'] / 2
                                    )
                                    click_success = True
                                    print("鼠标模拟点击成功")
                            except Exception as e:
                                print(f"鼠标模拟点击失败: {str(e)}")
                                
                        # 方法4：使用更复杂的JavaScript点击
                        if not click_success:
                            try:
                                self.page.evaluate("""(element) => {
                                    function triggerMouseEvent(node, eventType) {
                                        const event = new MouseEvent(eventType, {
                                            view: window,
                                            bubbles: true,
                                            cancelable: true,
                                            buttons: 1
                                        });
                                        node.dispatchEvent(event);
                                    }
                                    
                                    // 模拟完整的鼠标事件序列
                                    triggerMouseEvent(element, 'mouseover');
                                    triggerMouseEvent(element, 'mousedown');
                                    triggerMouseEvent(element, 'mouseup');
                                    triggerMouseEvent(element, 'click');
                                }""", element)
                                click_success = True
                                print("复杂JavaScript点击成功")
                            except Exception as e:
                                print(f"复杂JavaScript点击失败: {str(e)}")
                        
                        if click_success:
                            row_data['status'] = '成功'
                            time.sleep(2)  # 等待点击后的响应
                            
                            # 处理新窗口
                            try:
                                with self.context.expect_page(timeout=5000) as new_page_info:
                                    new_page = new_page_info.value
                                    if new_page:
                                        new_url = new_page.url
                                        print(f"检测到新页面: {new_url}")
                                        if new_url not in self.visited_urls:
                                            discovered_urls.add((new_url, depth + 1))
                                        new_page.close()
                            except TimeoutError:
                                pass
                        else:
                            row_data['status'] = '失败'
                            row_data['error'] = '所有点击方法都失败'
                            
                    except Exception as click_error:
                        print(f"点击处理时出错: {str(click_error)}")
                        row_data['status'] = '失败'
                        row_data['error'] = str(click_error)
                        
                    # 写入Excel
                    self.write_to_excel(row_data)
                    
                    # 如果URL改变，记录新URL并返回原页面
                    if self.page.url != url:
                        new_url = self.page.url
                        print(f"\n检测到URL变化: {new_url}")
                        # 检查新URL是否在允许列表中
                        if not allowed_urls or new_url in allowed_urls:
                            if new_url not in self.visited_urls:
                                discovered_urls.add((new_url, depth + 1))
                        else:
                            print(f"跳过非允许页面: {new_url}")
                        print("\n返回原页面...")
                        self.page.goto(url)
                        time.sleep(2)
                        
                except Exception as element_error:
                    print(f"处理元素时出错: {str(element_error)}")
                    continue
            
            # 处理发现的新页面时检查允许列表
            print(f"\n当前页面 {url} 遍历完成")
            valid_urls = discovered_urls
            if allowed_urls:
                valid_urls = {(url, depth) for url, depth in discovered_urls if url in allowed_urls}
                skipped = len(discovered_urls) - len(valid_urls)
                if skipped > 0:
                    print(f"跳过 {skipped} 个非允许页面")
                    
            print(f"发现 {len(valid_urls)} 个待处理的允许页面")
            
            for new_url, new_depth in sorted(valid_urls, key=lambda x: x[1]):
                if new_url not in self.visited_urls:
                    print(f"\n开始处理新页面: {new_url}")
                    self.process_page(new_url, new_depth, url, allowed_urls)
                    
        except Exception as e:
            print(f"处理页面时出错: {str(e)}")

    def get_clickable_elements(self):
        """获取页面上所有可点击的元素，并按位置排序"""
        try:
            # 使用JavaScript获取所有可点击元素及其位置信息
            elements_with_position = self.page.evaluate("""() => {
                const selectors = [
                    'button',
                    'a[href]',
                    'input[type="button"]',
                    'input[type="submit"]',
                    '[role="button"]',
                    '[onclick]',
                    '.btn',
                    '[class*="button"]',
                    '[tabindex]',
                    '[data-click]',
                    '[ng-click]',
                    '[v-on:click]',
                    '[data-toggle]',
                    'div[class*="click"]',
                    'span[class*="click"]'
                ];
                
                // 获取所有匹配的元素
                const elements = [];
                const seen = new Set(); // 用于去重
                
                selectors.forEach(selector => {
                    try {
                        document.querySelectorAll(selector).forEach(el => {
                            // 检查元素是否已经被处理过
                            if (seen.has(el)) return;
                            seen.add(el);
                            
                            const rect = el.getBoundingClientRect();
                            const style = window.getComputedStyle(el);
                            
                            // 检查元素是否可见且有尺寸
                            if (rect.width > 0 && rect.height > 0 && 
                                style.display !== 'none' && 
                                style.visibility !== 'hidden' &&
                                style.opacity !== '0') {
                                
                                elements.push({
                                    element: el,
                                    x: rect.left + window.scrollX,
                                    y: rect.top + window.scrollY,
                                    width: rect.width,
                                    height: rect.height,
                                    text: el.textContent.trim(),
                                    tag: el.tagName.toLowerCase()
                                });
                            }
                        });
                    } catch (error) {
                        console.error(`Error processing selector ${selector}:`, error);
                    }
                });
                
                // 按照从上到下，从左到右排序
                return elements.sort((a, b) => {
                    const yDiff = Math.abs(a.y - b.y);
                    // 如果y坐标相差小于30像素，认为是同一行
                    if (yDiff < 30) {
                        return a.x - b.x;  // 同一行按x坐标排序
                    }
                    return a.y - b.y;  // 不同行按y坐标排序
                });
            }""")
            
            # 将JavaScript元素转换为Playwright元素
            sorted_elements = []
            for element_info in elements_with_position:
                try:
                    # 使用相对准确的定位策略
                    locator = self.page.locator(f"""xpath=//*[
                        local-name()='{element_info['tag']}' and 
                        contains(text(), '{element_info['text'][:50]}')
                    ]""")
                    
                    # 获取所有匹配的元素
                    elements = locator.all()
                    
                    # 找到最匹配的元素
                    for element in elements:
                        box = element.bounding_box()
                        if box and \
                           abs(box['x'] - element_info['x']) < 5 and \
                           abs(box['y'] - element_info['y']) < 5:
                            sorted_elements.append(element)
                            break
                            
                except Exception as e:
                    print(f"处理元素时出错: {str(e)}")
                    continue
            
            print(f"找到 {len(sorted_elements)} 个可点击元素")
            return sorted_elements
            
        except Exception as e:
            print(f"获取可击元素时出错: {str(e)}")
            return []

    def is_element_clickable(self, element):
        """检查元素是否可点击"""
        try:
            # 检查元素是否可见且可交互
            return element.is_visible() and element.is_enabled()
        except:
            return False

    def get_element_info(self, element):
        """获取元详细信息"""
        try:
            # 获取元素属性
            tag_name = element.evaluate('el => el.tagName.toLowerCase()')
            text = element.text_content() or ''
            box = element.bounding_box()
            
            # 获取更多属性
            attrs = element.evaluate("""(el) => {
                const attrs = {};
                for (const attr of el.attributes) {
                    attrs[attr.name] = attr.value;
                }
                return attrs;
            }""")
            
            # 构建元素信息
            info = {
                'type': tag_name,
                'text': text.strip(),
                'position': f"x={box['x']:.0f}, y={box['y']:.0f}",
                'size': f"w={box['width']:.0f}, h={box['height']:.0f}",
                'attributes': attrs
            }
            
            return info
        except:
            return {
                'type': 'unknown',
                'text': '',
                'position': '',
                'size': '',
                'attributes': {}
            }

    def highlight_element(self, element):
        """高亮显示元素"""
        try:
            element.evaluate("""el => {
                el.style.border = '2px solid red';
                el.style.backgroundColor = 'yellow';
                setTimeout(() => {
                    el.style.border = '';
                    el.style.backgroundColor = '';
                }, 1000);
            }""")
            time.sleep(1)
        except:
            pass

    def take_screenshot(self, prefix):
        """保存截图"""
        try:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"{prefix}_{timestamp}.png"
            filepath = os.path.join(self.screenshots_dir, filename)
            
            self.page.screenshot(path=filepath)
            
            # 优化图片大小
            with PILImage.open(filepath) as img:
                img.thumbnail((800, 600), PILImage.Resampling.LANCZOS)
                img.save(filepath, optimize=True, quality=85)
                
            return filepath
        except Exception as e:
            print(f"截图失败: {str(e)}")
            return ''

    def start(self, url, allowed_urls=None):
        """
        开始处理页面
        :param url: 起始URL
        :param allowed_urls: 允许遍历的URL列表，如果为None则不限制
        """
        try:
            print(f"\n开始处理页面: {url}")
            self.current_url = url
            
            # 如果提供了allowed_urls，确保它是一个集合
            if allowed_urls:
                # 将字符串URL转换为集合
                if isinstance(allowed_urls, str):
                    allowed_urls = {allowed_urls}
                else:
                    allowed_urls = set(allowed_urls)
                
                # 确保起始URL在允许列表中
                allowed_urls.add(url)
                print(f"\n限制遍历以下页面:")
                for allowed_url in allowed_urls:
                    print(f"- {allowed_url}")
                    
            self.process_page(url, allowed_urls=allowed_urls)
            
        except Exception as e:
            print(f"处理页面时出错: {str(e)}")
        finally:
            try:
                self.save_results()
                self.browser.close()
                self.playwright.stop()
            except:
                pass

    # 其他辅助方法保持不变...
    def setup_logging(self):
        """设置日志"""
        try:
            logging.basicConfig(
                level=logging.INFO,
                format='%(asctime)s - %(levelname)s - %(message)s',
                handlers=[
                    logging.FileHandler('logs/crawler.log'),
                    logging.StreamHandler()
                ]
            )
            self.logger = logging.getLogger(__name__)
            
        except Exception as e:
            print(f"设置日志失败: {str(e)}")
            self.logger = logging.getLogger(__name__)

    def setup_excel(self):
        """设置Excel表头和格式"""
        try:
            headers = ['序号', '元素类型', '元素文本', '位置信息', '点击状态', '错误信息', '操作截图']
            for col, header in enumerate(headers, 1):
                cell = self.sheet.cell(row=1, column=col, value=header)
                
            # 调整列宽
            column_widths = [10, 15, 30, 20, 15, 30, 50]
            for i, width in enumerate(column_widths, 1):
                self.sheet.column_dimensions[chr(64 + i)].width = width
                
        except Exception as e:
            print(f"设置Excel格式失败: {str(e)}")

    def write_to_excel(self, row_data):
        """写入数据到Excel"""
        try:
            row = len(list(self.sheet.rows)) + 1
            
            # 写入基本数据
            self.sheet.cell(row=row, column=1, value=row_data['index'])
            self.sheet.cell(row=row, column=2, value=row_data['type'])
            self.sheet.cell(row=row, column=3, value=row_data['text'])
            self.sheet.cell(row=row, column=4, value=row_data['position'])
            self.sheet.cell(row=row, column=5, value=row_data['status'])
            self.sheet.cell(row=row, column=6, value=row_data['error'])
            
            # 处理截图
            if row_data['screenshot']:
                try:
                    # 设置行高以适应图片
                    self.sheet.row_dimensions[row].height = 120  # 设置行高为120像素
                    
                    # 调整列宽
                    self.sheet.column_dimensions['G'].width = 40  # 设置截图列宽为40字符
                    
                    # 读取并调整图片大小
                    img = Image(row_data['screenshot'])
                    
                    # 计算合适的图片大小（保持纵横比）
                    max_width = 180  # Excel中的最宽度（像素）
                    max_height = 100  # Excel中的最高度（像素）
                    
                    # 计算缩放比例
                    width_ratio = max_width / img.width
                    height_ratio = max_height / img.height
                    scale_ratio = min(width_ratio, height_ratio)
                    
                    # 设置新的图片大小
                    new_width = int(img.width * scale_ratio)
                    new_height = int(img.height * scale_ratio)
                    
                    # 应用新的大小
                    img.width = new_width
                    img.height = new_height
                    
                    # 将图片添加到单元格
                    cell = self.sheet.cell(row=row, column=7)
                    img.anchor = cell.coordinate
                    self.sheet.add_image(img)
                    
                    # 同时记录图片路径
                    self.sheet.cell(row=row, column=7, value=row_data['screenshot'])
                    
                except Exception as img_error:
                    print(f"添加图片到Excel时出错: {str(img_error)}")
                    # 如果添加图片失败，至少保存路径
                    self.sheet.cell(row=row, column=7, value=row_data['screenshot'])
                    
        except Exception as e:
            print(f"写入Excel失败: {str(e)}")

    def save_results(self):
        """保存结果到Excel"""
        try:
            result_file = os.path.join(self.result_dir, 'result.xlsx')
            self.workbook.save(result_file)
            print(f"\n结果已保存到: {result_file}")
            
            try:
                os.startfile(result_file)
            except:
                pass
                
        except Exception as e:
            print(f"保存结果失败: {str(e)}")
        
    def is_element_valid(self, element):
        """检查元素是否有效且可交互"""
        try:
            # 检查元素是否仍然存在于DOM中
            if not element:
                return False
            
            # 检查元素是否可见
            if not element.is_visible():
                return False
            
            # 检查元素是否启用
            if not element.is_enabled():
                return False
            
            # 检查元素大小和位置
            box = element.bounding_box()
            if not box:
                return False
            
            # 检查元素是否有有效大小
            if box['width'] < 1 or box['height'] < 1:
                return False
            
            # 检查元素是否在视口内和可见性
            viewport_check = element.evaluate("""(element) => {
                const box = element.getBoundingClientRect();
                const viewport = {
                    width: window.innerWidth || document.documentElement.clientWidth,
                    height: window.innerHeight || document.documentElement.clientHeight
                };
                const style = window.getComputedStyle(element);
                return {
                    inViewport: (
                        box.top < viewport.height &&
                        box.bottom > 0 &&
                        box.left < viewport.width &&
                        box.right > 0
                    ),
                    isVisible: style.display !== 'none' && style.visibility !== 'hidden'
                };
            }""")
            
            if not viewport_check['inViewport'] or not viewport_check['isVisible']:
                return False
            
            # 检查元素是否被其他元素遮挡
            is_not_covered = element.evaluate("""(element) => {
                const box = element.getBoundingClientRect();
                const center = {
                    x: box.left + box.width / 2,
                    y: box.top + box.height / 2
                };
                const elementAtPoint = document.elementFromPoint(center.x, center.y);
                return elementAtPoint === element || element.contains(elementAtPoint);
            }""")
            
            if not is_not_covered:
                return False
            
            return True
        
        except Exception as e:
            print(f"检查元素有效性时出错: {str(e)}")
            return False
        
    def scroll_page(self):
        """滚动整个页面以加载所有内容"""
        try:
            print("滚动页面以加载所有内容...")
            # 使用JavaScript滚动到页面底部
            last_height = self.page.evaluate("document.documentElement.scrollHeight")
            
            while True:
                # 滚动到底部
                self.page.evaluate("window.scrollTo(0, document.documentElement.scrollHeight)")
                time.sleep(2)  # 等待内容加载
                
                # 获取新的滚动高度
                new_height = self.page.evaluate("document.documentElement.scrollHeight")
                
                # 如果高度没有变化，说明已经到底部
                if new_height == last_height:
                    break
                    
                last_height = new_height
                
            # 滚动回顶部
            self.page.evaluate("window.scrollTo(0, 0)")
            time.sleep(1)
            
        except Exception as e:
            print(f"滚动页面时出错: {str(e)}")

    def is_element_in_viewport(self, element):
        """检查元素是否在视口中"""
        try:
            # 获取元素位置信息
            box = element.bounding_box()
            if not box:
                return False
            
            # 使用 JavaScript 检查元素是否在视口中
            return self.page.evaluate("""(rect) => {
                const vWidth = window.innerWidth || document.documentElement.clientWidth;
                const vHeight = window.innerHeight || document.documentElement.clientHeight;
                
                return (
                    rect.top >= 0 &&
                    rect.left >= 0 &&
                    rect.bottom <= vHeight &&
                    rect.right <= vWidth
                );
            }""", box)
            
        except Exception as e:
            print(f"检查元素是否在视口中时出错: {str(e)}")
            return False
        