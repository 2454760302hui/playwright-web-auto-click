import os
import yaml
import logging
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from openpyxl import Workbook
from datetime import datetime
import time
from urllib.parse import urljoin
import subprocess
import sys
import threading
from selenium.webdriver.common.keys import Keys
from collections import deque
import webbrowser
from selenium.webdriver.common.action_chains import ActionChains

# 在文件开头添加这行代码来获取当前脚本的目录
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(SCRIPT_DIR)

def format_url(url):
    """格式化URL，确保包含协议头"""
    url = url.strip()  # 移除首尾空格
    if not url:
        raise ValueError("URL不能为空")
    
    # 如果URL不以http或https开头，添加https://
    if not url.startswith(('http://', 'https://')):
        url = f'https://{url}'
    
    # 确保域名格式正确
    if not any(url.startswith(f'http{"s" if "https://" in url else ""}://{prefix}') 
               for prefix in ['www.', 'http://', 'https://']):
        if not url.startswith(('https://www.', 'http://www.')):
            url = url.replace('https://', 'https://www.')
            url = url.replace('http://', 'http://www.')
    
    return url

class WebCrawler:
    def __init__(self, config_path, use_proxy=True):
        self.running = True
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                self.config = yaml.safe_load(f)
        except Exception as e:
            raise Exception(f"加载配置文件失败: {str(e)}")
        
        try:
            self.log_message("正在启动Chrome浏览器...")
            chrome_options = Options()
            chrome_options.add_argument('--no-sandbox')
            chrome_options.add_argument('--disable-dev-shm-usage')
            chrome_options.add_argument('--disable-gpu')
            chrome_options.add_argument('--start-maximized')
            chrome_options.add_experimental_option('excludeSwitches', ['enable-automation'])
            chrome_options.add_experimental_option('useAutomationExtension', False)
            
            if use_proxy:
                chrome_options.add_argument('--proxy-server=http://127.0.0.1:8080')
                chrome_options.add_argument('--ignore-certificate-errors')
            
            try:
                self.driver = webdriver.Chrome(options=chrome_options)
                self.log_message("Chrome浏览器已成功启动")
            except Exception as browser_error:
                raise Exception(f"启动Chrome浏览器失败: {str(browser_error)}")
            
            # 初始化其他属性
            self.workbook = Workbook()
            self.sheet = self.workbook.active
            self.setup_excel()
            self.visited_urls = set()
            self.visited_elements = set()
            self.element_queue = deque()
            self.url_queue = deque()
            self.actions = ActionChains(self.driver)
            
        except Exception as e:
            # 确保清理资源
            if hasattr(self, 'driver'):
                try:
                    self.driver.quit()
                except:
                    pass
            raise Exception(f"初始化爬虫失败: {str(e)}")

    def stop(self):
        """停止爬虫"""
        self.running = False
        self.log_message("正在停止爬虫...")
        try:
            if hasattr(self, 'driver'):
                self.driver.quit()
        except Exception as e:
            self.log_message(f"关闭浏览器时出错: {str(e)}")

    def run(self, start_url):
        """运行爬虫"""
        try:
            self.log_message(f"开始爬取页面: {start_url}")
            self.bfs_crawl(start_url)
        except Exception as e:
            self.log_message(f"爬虫运行出错: {str(e)}")
        finally:
            if self.running:  # 只有在正常运行状态下才保存报告
                try:
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                    report_path = f'crawler_report_{timestamp}.xlsx'
                    self.workbook.save(report_path)
                    self.log_message(f"报告已保存至: {report_path}")
                except Exception as save_error:
                    self.log_message(f"保存报告时出错: {str(save_error)}")
            
            try:
                self.driver.quit()
            except:
                pass

    def bfs_crawl(self, start_url):
        """使用BFS算法爬取页面"""
        self.url_queue.append(start_url)
        
        while self.url_queue and self.running:  # 添加运行状态检查
            try:
                current_url = self.url_queue.popleft()
                if current_url in self.visited_urls:
                    continue
                
                self.log_message(f"\n正在访问页面: {current_url}")
                self.driver.get(current_url)
                self.visited_urls.add(current_url)
                
                # 等待页面加载
                WebDriverWait(self.driver, self.config['crawler']['timeout']['page_load']).until(
                    EC.presence_of_element_located((By.TAG_NAME, "body"))
                )
                
                # 等待动态内容加载
                time.sleep(3)
                
                if not self.running:  # 检查是否应该停止
                    break
                
                # 滚动页面以加载所有元素
                self.scroll_page()
                
                # 获取并按层级组织元素
                elements_by_level = self.get_interactive_elements()
                
                # 按层级处理元素
                self.process_elements_by_level(elements_by_level, current_url)
                
            except Exception as e:
                self.log_message(f"处理页面时出错: {str(e)}")
                self.handle_page_error(current_url, str(e))
                continue

    def setup_excel(self):
        """设置Excel表头"""
        headers = ['时间', '页面URL', '元素类型', '元素文本', '元素XPath', 'API请求', '异常信息', '截图路径']
        for col, header in enumerate(headers, 1):
            self.sheet.cell(row=1, column=col, value=header)
            
    def wait_for_login(self):
        """等待用户登录"""
        login_elements = self.config['crawler']['login']['check_elements']
        for text in login_elements:
            try:
                elements = self.driver.find_elements(By.XPATH, f"//*[contains(text(), '{text}')]")
                if elements:
                    print("检测到登录页面，请手动登录...")
                    # 等待登录完成
                    wait_time = self.config['crawler']['login']['wait_time']
                    print(f"等待 {wait_time} 秒进行登录...")
                    time.sleep(wait_time)
                    # 检查登录是否成功
                    if not any(self.driver.find_elements(By.XPATH, f"//*[contains(text(), '{text}')]")):
                        print("登录成功，继续爬取...")
                        return False
                    else:
                        print("登录超时，停止爬取...")
                        return True
            except Exception as e:
                print(f"检查登录元素时出错: {str(e)}")
                continue
        return False
    
    def capture_screenshot(self, error):
        """捕获异常截图"""
        if not self.config['crawler']['screenshot']['enabled']:
            return None
            
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        screenshot_path = os.path.join(
            self.config['crawler']['screenshot']['path'],
            f'error_{timestamp}.png'
        )
        os.makedirs(os.path.dirname(screenshot_path), exist_ok=True)
        self.driver.save_screenshot(screenshot_path)
        return screenshot_path
        
    def get_element_info(self, element):
        """获取元素信息"""
        try:
            return {
                'element': element,
                'type': element.tag_name,
                'text': element.text or element.get_attribute('value') or element.get_attribute('placeholder'),
                'xpath': self.get_element_xpath(element),
                'href': element.get_attribute('href'),
                'onclick': element.get_attribute('onclick')
            }
        except:
            return None

    def process_element_queue(self):
        """处理元素队列"""
        while self.element_queue:
            element_info, current_url = self.element_queue.popleft()
            if element_info['xpath'] in self.visited_elements:
                continue
                
            try:
                print(f"\n处理元素: {element_info['type']} - {element_info['text']}")
                
                # 高亮显示当前元素
                self.highlight_element(element_info['element'])
                
                # 记录元素信息
                row = [
                    datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    current_url,
                    element_info['type'],
                    element_info['text'],
                    element_info['xpath'],
                    '',
                    '',
                    ''
                ]
                
                # 与元素交互
                if self.should_interact_with_element(element_info['element']):
                    try:
                        # 获取当前窗口信息
                        original_window = self.driver.current_window_handle
                        original_handles = set(self.driver.window_handles)
                        
                        # 执行交互
                        self.interact_with_element(element_info['element'], current_url)
                        
                        # 处理新窗口
                        new_handles = set(self.driver.window_handles) - original_handles
                        if new_handles:
                            for handle in new_handles:
                                self.driver.switch_to.window(handle)
                                new_url = self.driver.current_url
                                if new_url not in self.visited_urls:
                                    self.url_queue.append(new_url)
                                self.driver.close()
                            self.driver.switch_to.window(original_window)
                        
                        # 检查URL变化
                        new_url = self.driver.current_url
                        if new_url != current_url and new_url not in self.visited_urls:
                            self.url_queue.append(new_url)
                            self.driver.back()
                            time.sleep(2)
                        
                    except Exception as e:
                        print(f"元素交互失败: {str(e)}")
                        row[-2] = str(e)
                        row[-1] = self.capture_screenshot(str(e))
                
                self.sheet.append(row)
                self.visited_elements.add(element_info['xpath'])
                
            except Exception as e:
                print(f"处理元素时出错: {str(e)}")
                continue

    def scroll_page(self):
        """滚动页面以加载所有元素"""
        try:
            last_height = self.driver.execute_script("return document.body.scrollHeight")
            while True:
                # 滚动到页面底部
                self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                time.sleep(2)  # 等待页面加载
                
                # 计算新的滚动高度并与上一次的滚动高度进行比较
                new_height = self.driver.execute_script("return document.body.scrollHeight")
                if new_height == last_height:
                    break
                last_height = new_height
        except Exception as e:
            print(f"滚动页面时出错: {str(e)}")

    def should_interact_with_element(self, element):
        """判断是否应该与元素交互"""
        try:
            # 检查元素是否可见且可交互
            if not element.is_displayed() or not element.is_enabled():
                return False
            
            element_type = element.tag_name
            element_class = element.get_attribute('class')
            element_style = element.get_attribute('style')
            
            # 检查元素是否隐藏
            if 'display: none' in str(element_style) or 'visibility: hidden' in str(element_style):
                return False
            
            # 检查元素是否在黑名单中
            blacklist_classes = ['disabled', 'hidden', 'inactive']
            if any(cls in str(element_class).lower() for cls in blacklist_classes):
                return False
            
            # 检查元素是否有点击相关属性
            has_click_handler = (
                element.get_attribute('onclick') or 
                element.get_attribute('href') or 
                'button' in str(element_class).lower() or 
                'btn' in str(element_class).lower() or
                element.get_attribute('role') == 'button'
            )
            
            # 根据元素类型判断是否可交互
            if element_type in ['button', 'a', 'select']:
                return True
            elif element_type == 'input':
                input_type = element.get_attribute('type')
                return input_type in ['button', 'submit', 'text', 'email', 'password', 'radio', 'checkbox']
            elif has_click_handler:
                return True
            
            return False
        except:
            return False

    def interact_with_element(self, element, current_url):
        """与元素进行交互"""
        try:
            element_type = element.tag_name
            input_type = element.get_attribute('type')
            
            # 高亮显示当前操作的元素
            self.highlight_element(element)
            
            # 记录当前窗口和URL状态
            original_window = self.driver.current_window_handle
            original_handles = set(self.driver.window_handles)
            
            # 根据元素类型执行不同的操作
            if element_type == 'input' and input_type in ['text', 'email', 'password']:
                # 对于输入框，输入测试数据
                element.clear()
                element.send_keys("test_input")
                time.sleep(1)
                
                # 模拟回车键
                element.send_keys(Keys.RETURN)
                time.sleep(2)
                
            elif element_type == 'select':
                # 对于下拉框，遍历所有选项
                options = element.find_elements(By.TAG_NAME, "option")
                for option in options[:3]:  # 限制只测试前3个选项
                    option.click()
                    time.sleep(1)
                    self.check_page_changes(original_window, current_url)
                    
            else:
                # 使用增强的点击方法
                if self.click_element(element):
                    print(f"成功点击元素: {element.text or element.get_attribute('value')}")
                    time.sleep(2)
                else:
                    print(f"无法点击元素: {element.text or element.get_attribute('value')}")
            
            # 检查页面变化
            self.check_page_changes(original_window, current_url)
            
            # 检查是否有新窗口打开
            new_handles = set(self.driver.window_handles) - original_handles
            if new_handles:
                self.handle_new_windows(new_handles, original_window)
                
        except Exception as e:
            print(f"元素交互失败: {str(e)}")
            raise

    def check_page_changes(self, original_window, original_url):
        """检查页面变化并处理"""
        try:
            # 确保焦点在正确的窗口
            if self.driver.current_window_handle != original_window:
                self.driver.switch_to.window(original_window)
            
            # 获取当前URL
            current_url = self.driver.current_url
            
            # 如果URL发生变化且模式允许
            if current_url != original_url and self.config['crawler']['mode'] in [2, 3]:
                if current_url not in self.visited_urls:
                    print(f"检测到页面变化，开始爬取新页面: {current_url}")
                    self.crawl_page(current_url)
                    
                    # 回上一页
                    self.driver.back()
                    time.sleep(2)
                    
                    # 重新爬取原始页面上剩余的元素
                    if original_url not in self.visited_urls:
                        self.crawl_page(original_url)
                        
        except Exception as e:
            print(f"检查页面变化时出错: {str(e)}")

    def handle_new_windows(self, new_handles, original_window):
        """处理新打开的窗口"""
        if self.config['crawler']['mode'] == 3:
            for handle in new_handles:
                try:
                    self.driver.switch_to.window(handle)
                    new_url = self.driver.current_url
                    
                    if new_url not in self.visited_urls:
                        print(f"处理新窗口: {new_url}")
                        self.crawl_page(new_url)
                    
                    self.driver.close()
                    
                except Exception as e:
                    print(f"处理新窗口时出错: {str(e)}")
                    continue
                
            # 切回原始窗口
            self.driver.switch_to.window(original_window)

    def handle_page_error(self, url, error_message):
        """处理页面错误"""
        screenshot_path = self.capture_screenshot(error_message)
        self.sheet.append([
            datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            url,
            'error',
            '',
            '',
            '',
            error_message,
            screenshot_path
        ])

    def get_element_xpath(self, element):
        """获取元素的XPath"""
        return self.driver.execute_script("""
            function getXPath(element) {
                if (element.id !== '')
                    return `//*[@id="${element.id}"]`;
                if (element === document.body)
                    return element.tagName.toLowerCase();

                var ix = 0;
                var siblings = element.parentNode.childNodes;
                for (var i = 0; i < siblings.length; i++) {
                    var sibling = siblings[i];
                    if (sibling === element)
                        return getXPath(element.parentNode) + '/' + element.tagName.toLowerCase() + '[' + (ix + 1) + ']';
                    if (sibling.nodeType === 1 && sibling.tagName === element.tagName)
                        ix++;
                }
            }
            return getXPath(arguments[0]);
        """, element)
        
    def should_click_element(self, element_type):
        """根据配置的权重决定是否点击元素"""
        weights = self.config['crawler']['weights']
        return element_type in weights and weights[element_type] > 5
        
    def is_element_clickable(self, element):
        """检查元素是否可点击"""
        try:
            # 检查元素是否在视图中
            self.driver.execute_script("arguments[0].scrollIntoView(true);", element)
            time.sleep(0.5)  # 等待滚动完成
            
            # 检查元素是否可见且可交互
            return (element.is_displayed() and 
                    element.is_enabled() and 
                    element.size['height'] > 0 and 
                    element.size['width'] > 0)
        except:
            return False

    def handle_new_window(self, original_window, original_url):
        """处理新窗口"""
        try:
            # 检查是否打开了新窗口
            if len(self.driver.window_handles) > 1:
                if self.config['crawler']['mode'] == 3:
                    for window_handle in self.driver.window_handles:
                        if window_handle != original_window:
                            self.driver.switch_to.window(window_handle)
                            new_url = self.driver.current_url
                            if new_url not in self.visited_urls:
                                self.crawl_page(new_url)
                            self.driver.close()
                    self.driver.switch_to.window(original_window)
            
            # 检查当前页面是否发生变化
            elif self.config['crawler']['mode'] in [2, 3]:
                current_url = self.driver.current_url
                if current_url != original_url and current_url not in self.visited_urls:
                    self.crawl_page(current_url)
                    self.driver.back()
                    time.sleep(1)
        except Exception as e:
            print(f"处理新窗口时出错: {str(e)}")

    def highlight_element(self, element):
        """使用红色边框高亮显示元素"""
        try:
            # 保存原始样式
            original_style = element.get_attribute('style')
            
            # 添加红色边框
            self.driver.execute_script("""
                arguments[0].style.border = '2px solid red';
                arguments[0].style.boxShadow = '0 0 10px red';
            """, element)
            
            # 等待一段时间以显示高亮效果
            time.sleep(1)
            
            # 恢复原始样式
            if original_style:
                self.driver.execute_script(f"arguments[0].style = '{original_style}';", element)
            else:
                self.driver.execute_script("""
                    arguments[0].style.border = '';
                    arguments[0].style.boxShadow = '';
                """, element)
                
        except Exception as e:
            print(f"高亮元素时出错: {str(e)}")

    def get_interactive_elements(self):
        """获取所有可交互元素，按层级组织"""
        try:
            elements_by_level = {}  # 按层级存储元素
            
            # 使用更可靠的选择器
            selectors = [
                "button", 
                "input[type='button']", 
                "input[type='submit']",
                "input[type='text']",
                "input[type='radio']",
                "input[type='checkbox']",
                "select",
                "a[href]",
                "textarea",
                ".btn",
                "[role='button']",
                "[onclick]",
                "[class*='button']",
                "[class*='btn']"
            ]
            
            # 使用 CSS 选择器查找元素
            for selector in selectors:
                try:
                    elements = WebDriverWait(self.driver, 10).until(
                        EC.presence_of_all_elements_located((By.CSS_SELECTOR, selector))
                    )
                    
                    for element in elements:
                        try:
                            if not self.is_valid_element(element):
                                continue
                                
                            # 获取元素层级
                            level = self.get_element_level_safe(element)
                            
                            # 创建元素信息
                            element_info = {
                                'element': element,
                                'id': element.get_attribute('id') or '',
                                'class': element.get_attribute('class') or '',
                                'type': element.tag_name,
                                'text': self.get_element_text_safe(element),
                                'level': level,
                                'xpath': self.get_element_xpath_safe(element),
                                'clickable': True
                            }
                            
                            # 按层级存储元素
                            if level not in elements_by_level:
                                elements_by_level[level] = []
                            elements_by_level[level].append(element_info)
                            
                        except Exception as elem_error:
                            print(f"处理单个元素时出错: {str(elem_error)}")
                            continue
                            
                except Exception as selector_error:
                    print(f"处理选择器 {selector} 时出错: {str(selector_error)}")
                    continue
            
            # 打印找到的元素信息
            print("\n按层级组织的可交互元素:")
            for level in sorted(elements_by_level.keys()):
                elements = elements_by_level[level]
                print(f"\n层级 {level}: 找到 {len(elements)} 个元素")
                for elem in elements[:5]:  # 只打印前5个元素避免输出过多
                    print(f"  - {elem['type']}: {elem['text'][:50]}...")
            
            return elements_by_level
            
        except Exception as e:
            print(f"获取交互元素时出错: {str(e)}")
            return {}

    def is_valid_element(self, element):
        """检查元素是否有效且可交互"""
        try:
            # 检查元素是否仍然附加到DOM
            self.driver.execute_script("return arguments[0].nodeType;", element)
            
            # 检查元素是否可见
            if not element.is_displayed():
                return False
            
            # 检查元素是否启用
            if not element.is_enabled():
                return False
            
            # 检查元素大小
            size = element.size
            if size['width'] == 0 or size['height'] == 0:
                return False
            
            return True
        except:
            return False

    def get_element_level_safe(self, element):
        """安全地获取元素层级"""
        try:
            script = """
                var element = arguments[0];
                var level = 0;
                while (element.parentElement) {
                    element = element.parentElement;
                    level++;
                }
                return level;
            """
            return self.driver.execute_script(script, element)
        except:
            return 0

    def get_element_text_safe(self, element):
        """安全地获取元素文本"""
        try:
            text = element.text
            if not text:
                text = element.get_attribute('value')
            if not text:
                text = element.get_attribute('placeholder')
            return text.strip() if text else ''
        except:
            return ''

    def get_element_xpath_safe(self, element):
        """安全地获取元素XPath"""
        try:
            script = """
                function getXPath(element) {
                    if (!element) return '';
                    if (element.id) return `//*[@id="${element.id}"]`;
                    if (element === document.body) return '//' + element.tagName.toLowerCase();
                    
                    var path = '';
                    while (element) {
                        var tag = element.tagName.toLowerCase();
                        var siblings = Array.from(element.parentNode.children).filter(e => e.tagName === element.tagName);
                        var index = siblings.indexOf(element) + 1;
                        path = `/${tag}[${index}]${path}`;
                        element = element.parentNode;
                        if (element === document.body) break;
                    }
                    return '//' + path;
                }
                return getXPath(arguments[0]);
            """
            return self.driver.execute_script(script, element)
        except:
            return ''

    def process_elements_by_level(self, elements_by_level, current_url):
        """按层级处理元素"""
        try:
            # 按层级顺序处理元素
            for level in sorted(elements_by_level.keys()):
                elements = elements_by_level[level]
                print(f"\n处理第 {level} 层级的元素 (共 {len(elements)} 个)")
                
                for element_info in elements:
                    try:
                        if element_info['xpath'] in self.visited_elements:
                            continue
                            
                        element = element_info['element']
                        print(f"\n正在处理: {element_info['type']} - {element_info['text']}")
                        
                        # 高亮显示当前元素
                        self.highlight_element(element)
                        
                        # 记录元素信息
                        row = [
                            datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                            current_url,
                            element_info['type'],
                            element_info['text'],
                            element_info['xpath'],
                            '',
                            '',
                            ''
                        ]
                        
                        try:
                            # 尝试与元素交互
                            self.interact_with_element(element, current_url)
                            print(f"成功与元素交互: {element_info['text']}")
                        except Exception as e:
                            print(f"元素交互失败: {str(e)}")
                            row[-2] = str(e)
                            row[-1] = self.capture_screenshot(str(e))
                        
                        self.sheet.append(row)
                        self.visited_elements.add(element_info['xpath'])
                        
                    except Exception as e:
                        print(f"处理元素时出错: {str(e)}")
                        continue
                        
        except Exception as e:
            print(f"按层级处理元素时出错: {str(e)}")

    def click_element(self, element):
        """使用多种方式尝试点击元素"""
        try:
            # 1. 首先尝试使用 ActionChains 点击
            try:
                self.actions.move_to_element(element).click().perform()
                return True
            except:
                pass

            # 2. 尝试使用 JavaScript 点击
            try:
                self.driver.execute_script("arguments[0].click();", element)
                return True
            except:
                pass

            # 3. 如果是链接，尝试使用 webbrowser 打开
            href = element.get_attribute('href')
            if href:
                try:
                    current_window = self.driver.current_window_handle
                    webbrowser.open(href)
                    time.sleep(2)
                    # 切换到新窗口
                    for handle in self.driver.window_handles:
                        if handle != current_window:
                            self.driver.switch_to.window(handle)
                            break
                    return True
                except:
                    pass

            # 4. 尝试模拟鼠标事件
            try:
                self.driver.execute_script("""
                    var evt = new MouseEvent('click', {
                        bubbles: true,
                        cancelable: true,
                        view: window
                    });
                    arguments[0].dispatchEvent(evt);
                """, element)
                return True
            except:
                pass

            return False
        except Exception as e:
            print(f"点击元素失败: {str(e)}")
            return False

    def log_message(self, message):
        """默认的日志输出方法"""
        print(message)

def main():
    if __name__ == "__main__":
        try:
            # 使用绝对路径来定位配置文件
            config_path = os.path.join(PROJECT_ROOT, 'config', 'crawler_config.yml')
            
            # 检查配置文件是否存在
            if not os.path.exists(config_path):
                # 如果配置文件不存在，创建默认配置
                os.makedirs(os.path.dirname(config_path), exist_ok=True)
                default_config = '''# 爬虫配置
crawler:
  # 遍历模式
  mode: 1  # 1-当前页面元素 2-所有层级 3-所有层级包含新开页面
  
  # 元素权重配置
  weights:
    button: 10
    input: 8
    link: 7
    select: 6
    
  # 截图配置
  screenshot:
    enabled: true
    path: "./screenshots/"
    
  # 超时配置
  timeout:
    page_load: 30
    element_wait: 10
    
  # 登录配置
  login:
    check_elements: ["登录", "signin", "login"]
    wait_time: 300  # 等待用户登录的最大时间(秒)
'''
                with open(config_path, 'w', encoding='utf-8') as f:
                    f.write(default_config)
                print(f"已创建默认配置文件: {config_path}")

            print("正在初始化爬虫...")
            url = input("请输入要爬取的网页地址：")
            url = format_url(url)  # 格式化URL
            print(f"格式化后的URL: {url}")
            
            try:
                crawler = WebCrawler(config_path, use_proxy=False)
                print("爬初始化成功，开始运行...")
                crawler.run(url)
            except Exception as crawler_error:
                print(f"爬虫运行出错: {str(crawler_error)}")
                if "chromedriver" in str(crawler_error).lower():
                    print("\n可能的解决方案:")
                    print("1. 确保已安装最新版本的Chrome浏览器")
                    print("2. 确保Chrome浏览器可以正常打开")
                    print("3. 尝试重启电脑后再运行程序")
                    print("\n当前系统信息:")
                    if os.name == 'nt':
                        chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
                        if os.path.exists(chrome_path):
                            print(f"找到Chrome浏览器: {chrome_path}")
                        else:
                            print("未找到Chrome浏览器在默认安装路径")
                raise
        except Exception as e:
            print(f"程序运行出错: {str(e)}")
            input("按回车键退出...")
        finally:
            # 确保程序不会立即退出
            print("\n程序已结束，按回车键退出...")
            input() 