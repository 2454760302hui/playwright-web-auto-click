from mitmproxy import ctx
import json

def request(flow):
    """记录请求信息"""
    with open('api_requests.log', 'a', encoding='utf-8') as f:
        request_info = {
            'url': flow.request.pretty_url,
            'method': flow.request.method,
            'headers': dict(flow.request.headers),
            'content': flow.request.content.decode('utf-8', 'ignore') if flow.request.content else ''
        }
        f.write(json.dumps(request_info) + '\n')

def response(flow):
    """记录响应信息"""
    with open('api_responses.log', 'a', encoding='utf-8') as f:
        response_info = {
            'url': flow.request.pretty_url,
            'status_code': flow.response.status_code,
            'headers': dict(flow.response.headers),
            'content': flow.response.content.decode('utf-8', 'ignore') if flow.response.content else ''
        }
        f.write(json.dumps(response_info) + '\n') 