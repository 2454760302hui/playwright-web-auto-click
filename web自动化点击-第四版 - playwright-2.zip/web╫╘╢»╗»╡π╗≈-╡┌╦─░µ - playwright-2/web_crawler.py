from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from urllib.parse import urljoin, urlparse
import time
import json
from datetime import datetime

class WebCrawler:
    def __init__(self):
        # 初始化Chrome选项
        options = webdriver.ChromeOptions()
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--start-maximized')
        
        # 初始化浏览器
        self.driver = webdriver.Chrome(options=options)
        self.wait = WebDriverWait(self.driver, 10)
        
        # 初始化存储
        self.visited_urls = set()
        self.visited_elements = set()
        self.results = []
        
    def start(self, url):
        """开始爬取指定URL"""
        try:
            print(f"开始爬取: {url}")
            self.crawl_page(url)
            self.save_results()
        finally:
            self.driver.quit()
            
    def crawl_page(self, url):
        """爬取单个页面"""
        if url in self.visited_urls:
            return
            
        try:
            # 访问页面
            self.driver.get(url)
            self.visited_urls.add(url)
            print(f"\n正在访问: {url}")
            
            # 等待页面加载
            self.wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))
            time.sleep(2)  # 额外等待动态内容
            
            # 滚动页面以加载所有内容
            self.scroll_page()
            
            # 查找并处理所有可交互元素
            self.find_and_interact_elements()
            
        except Exception as e:
            print(f"处理页面出错: {url} - {str(e)}")
            
    def scroll_page(self):
        """滚动页面加载所有内容"""
        last_height = self.driver.execute_script("return document.body.scrollHeight")
        while True:
            # 滚动到底部
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(2)
            
            # 检查是否到达底部
            new_height = self.driver.execute_script("return document.body.scrollHeight")
            if new_height == last_height:
                break
            last_height = new_height
            
    def find_and_interact_elements(self):
        """查找并与页面元素交互"""
        # 定义要查找的元素类型
        selectors = [
            "button",
            "a[href]",
            "input[type='button']",
            "input[type='submit']",
            "[role='button']",
            "[onclick]",
            ".btn",
            "[class*='button']"
        ]
        
        for selector in selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                for element in elements:
                    try:
                        if not self.should_interact(element):
                            continue
                            
                        # 记录元素信息
                        element_info = self.get_element_info(element)
                        
                        # 高亮显示当前元素
                        self.highlight_element(element)
                        
                        # 尝试点击元素
                        self.click_element(element)
                        
                        # 记录结果
                        self.results.append({
                            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                            'url': self.driver.current_url,
                            'element': element_info
                        })
                        
                    except Exception as e:
                        print(f"处理元素时出错: {str(e)}")
                        continue
                        
            except Exception as e:
                print(f"查找元素出错 {selector}: {str(e)}")
                continue
                
    def should_interact(self, element):
        """判断是否应该与元素交互"""
        try:
            # 检查元素是否可见且可交互
            if not element.is_displayed() or not element.is_enabled():
                return False
                
            # 检查元素是否已访问
            element_id = self.get_element_identifier(element)
            if element_id in self.visited_elements:
                return False
                
            # 记录已访问
            self.visited_elements.add(element_id)
            return True
            
        except:
            return False
            
    def get_element_info(self, element):
        """获取元素信息"""
        return {
            'tag_name': element.tag_name,
            'text': element.text or element.get_attribute('value'),
            'href': element.get_attribute('href'),
            'id': element.get_attribute('id'),
            'class': element.get_attribute('class')
        }
        
    def get_element_identifier(self, element):
        """生成元素的唯一标识符"""
        return f"{element.tag_name}_{element.text}_{element.get_attribute('href')}_{element.get_attribute('id')}"
        
    def highlight_element(self, element):
        """高亮显示元素"""
        try:
            original_style = element.get_attribute('style')
            self.driver.execute_script("""
                arguments[0].style.border = '2px solid red';
                arguments[0].style.backgroundColor = 'yellow';
            """, element)
            time.sleep(0.5)
            self.driver.execute_script(f"arguments[0].style = '{original_style}';", element)
        except:
            pass
            
    def click_element(self, element):
        """尝试点击元素"""
        try:
            # 保存当前窗口句柄
            current_window = self.driver.current_window_handle
            
            # 尝试点击
            element.click()
            time.sleep(2)
            
            # 处理新窗口
            if len(self.driver.window_handles) > 1:
                for handle in self.driver.window_handles:
                    if handle != current_window:
                        self.driver.switch_to.window(handle)
                        new_url = self.driver.current_url
                        if new_url not in self.visited_urls:
                            self.crawl_page(new_url)
                        self.driver.close()
                self.driver.switch_to.window(current_window)
                
            return True
        except Exception as e:
            print(f"点击元素失败: {str(e)}")
            return False
            
    def save_results(self):
        """保存爬取结果"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'crawler_results_{timestamp}.json'
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump({
                'visited_urls': list(self.visited_urls),
                'elements': self.results
            }, f, ensure_ascii=False, indent=2)
            
        print(f"\n结果已保存到: {filename}")
        print(f"共访问了 {len(self.visited_urls)} 个页面")
        print(f"共处理了 {len(self.results)} 个元素")

def main():
    url = input("请输入要爬取的网址: ")
    crawler = WebCrawler()
    try:
        crawler.start(url)
    except Exception as e:
        print(f"爬虫运行出错: {str(e)}")
    finally:
        input("按回车键退出...")

if __name__ == "__main__":
    main() 